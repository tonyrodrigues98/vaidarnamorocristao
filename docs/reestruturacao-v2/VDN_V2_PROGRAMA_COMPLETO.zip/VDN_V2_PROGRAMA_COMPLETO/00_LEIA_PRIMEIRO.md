# Vai Dar Namoro V2 — programa completo de reconstrução

Este pacote corrige a limitação dos prompts anteriores: ele não cobre apenas o
que já foi preparado nem termina na V2-007. Ele transforma todo o planejamento
dos dez documentos originais em um programa executável, contínuo e autônomo para
o Codex.

## Resultado pretendido

Reconstruir o Vai Dar Namoro Cristão como uma plataforma social cristã
**community-first**, premium, mobile-first e modular, preservando todos os dados
e sistemas legítimos enquanto:

- namoro deixa de ser a identidade obrigatória do produto e vira um modo
  paralelo, opcional e reversível;
- a experiência antiga de Pretendentes é substituída com paridade e migração
  segura;
- Perfil, Início, Comunidade, Conversas, Propósito Firmado, Loja, economia,
  inventário, pets, jogos, notificações, suporte e Administração são
  reconstruídos ou redesenhados;
- Status de 24 horas, vínculos sociais, grupos/espaços, Verbo e Sala de Cinema
  são criados;
- monólitos, duplicações, regras no frontend e gambiarras são substituídos por
  fronteiras de domínio e contratos testáveis;
- o avatar-personagem é aposentado sem atingir foto de perfil, molduras, auras,
  fundos, gradientes, presentes, stickers ou inventários legítimos;
- PWA, offline, cache, Realtime, segurança, acessibilidade e desempenho passam
  a fazer parte do critério de pronto;
- legado só é removido depois de paridade, reconciliação, observabilidade,
  rollback e autorização adequada.

O trabalho não está concluído quando as telas existem. Está concluído quando a
base inteira está preparada para operar com segurança, os domínios estão
isolados, os dados preservados, os fluxos testados e o legado elegível para
retirada controlada.

## Como usar

### Uso recomendado

1. Coloque esta pasta no repositório, preferencialmente em
   `docs/reestruturacao-v2/programa-completo/`.
2. Preserve os documentos já existentes em `docs/reestruturacao-v2/`.
3. Incorpore `02_REGRAS_PERMANENTES_AGENTS.md` ao `AGENTS.md` da raiz, sem
   apagar regras locais mais específicas.
4. Envie ao Codex somente o conteúdo de
   `01_SUPERPROMPT_AUTONOMO_PROGRAMA_COMPLETO.md`.
5. O próprio superprompt manda o Codex ler todos os demais arquivos.

Não é necessário colar cada lote manualmente. Os arquivos em `lotes/` são
especificações que o orquestrador lê conforme chega à etapa correspondente.

### Se a sessão for interrompida

Envie somente `06_PROMPT_RETOMADA_AUTONOMA.md`. O estado curto e persistente do
repositório deve permitir continuar sem repetir auditorias, explicações ou
prompts anteriores.

## Estrutura do pacote

| Arquivo | Finalidade |
|---|---|
| `00_LEIA_PRIMEIRO.md` | orientação de uso e escopo total |
| `01_SUPERPROMPT_AUTONOMO_PROGRAMA_COMPLETO.md` | comando único para executar o programa |
| `02_REGRAS_PERMANENTES_AGENTS.md` | regras duráveis de autonomia, arquitetura e segurança |
| `03_MATRIZ_TOTAL_ESCOPO_DOMINIOS.md` | mapa completo do produto e dos 17 domínios |
| `04_ROADMAP_LOTES_E_DEPENDENCIAS.md` | sequência V2-007 a V2-025 e gates |
| `05_PROTOCOLOS_TRANSVERSAIS.md` | segurança, dados, design, testes, PWA e release |
| `06_PROMPT_RETOMADA_AUTONOMA.md` | retomada curta após interrupção |
| `07_GATES_DECISOES_ANTONIO.md` | únicas decisões humanas que podem bloquear ativação |
| `08_CHECKPOINT_CANONICO_V2_006.md` | último estado auditado antes do programa |
| `lotes/*.md` | instruções completas de cada etapa futura |
| `fontes-originais/*` | os dez documentos originais, guia e plano de execução |

## Fontes originais incluídas

1. Manual do sistema atual.
2. Revisão oficial do escopo.
3. Plano de segurança.
4. Snapshot canônico do Supabase.
5. Inventário Supabase somente leitura.
6. Arquitetura por domínios.
7. Separação Comunidade/Namoro.
8. Desmontagem dos monólitos.
9. Preservação e migração.
10. Projeto da nova experiência.
11. Guia de aplicação com o Codex.
12. Plano de execução técnico.

## Regra de autoridade

Quando houver conflito:

1. instrução mais recente e explícita de Antonio Rodrigues;
2. revisão oficial do escopo;
3. projeto da nova experiência;
4. separação Comunidade/Namoro;
5. arquitetura por domínios;
6. preservação e migração;
7. plano de segurança;
8. desmontagem dos monólitos;
9. snapshot do Supabase;
10. manual do sistema atual;
11. protótipos visuais, apenas como direção de design e interação.

O código atual prova o presente. Os documentos superiores definem o destino.
Protótipos não definem schema, RLS, autorização, economia ou fonte de verdade.

## O que este pacote autoriza

Ao enviar o superprompt, Antonio autoriza o Codex a:

- inspecionar e editar o repositório;
- criar código, testes, documentação e migrations ainda não aplicadas;
- refatorar de forma incremental;
- corrigir obstáculos técnicos encontrados dentro do escopo;
- criar branches, commits coerentes e Draft PRs;
- manter uma pilha de Draft PRs quando a etapa anterior ainda não foi mesclada;
- executar validações locais seguras;
- continuar de um lote para o próximo sem pedir confirmação rotineira.

Não autoriza:

- merge;
- deploy;
- alteração do Supabase publicado;
- execução de migration em produção;
- exclusão física de dados, tabelas, buckets ou assets;
- uso ou exposição de secrets;
- contração irreversível do legado;
- decisão jurídica sobre mídia da Sala de Cinema;
- escolha por Antonio de jogos a retirar;
- compensação econômica do avatar-personagem;
- qualquer ação externa irreversível não explicitamente autorizada.

Quando um gate externo bloquear uma parte, o Codex deve continuar todas as
outras partes independentes e seguras antes de interromper.
