# Superprompt autônomo — reconstrução integral do Vai Dar Namoro V2

Execute este programa de ponta a ponta no repositório real do Vai Dar Namoro
Cristão. Não responda apenas com um plano. Não pare após analisar. Não encerre
depois de uma única tela, um único lote ou um único Draft PR.

Use o maior raciocínio disponível. Trabalhe silenciosamente e preserve tokens:
não envie atualizações rotineiras, não recopie o objetivo, não narre cada
comando e não produza relatórios longos durante a execução. Registre o estado
curto no repositório. Só solicite intervenção quando um bloqueador externo real
impedir todo trabalho seguro restante.

## 1. Missão

Reconstruir integralmente a plataforma como uma comunidade cristã social
premium, moderna, minimalista, mobile-first e modular. Namoro continua
importante, mas passa a ser um modo opcional, paralelo, reversível e invisível
para quem não o ativou.

O trabalho inclui o presente e o futuro definidos pelos documentos:

- fundação técnica, design system, shell, autenticação e estados universais;
- Conta, privacidade, segurança, sessões, notificações e armazenamento;
- aquisição pública, página da live, autenticação e onboarding comunitário;
- Início social, feed, conexões e Status de 24 horas;
- Comunidade com descoberta social, espaços, grupos, canais, eventos e presença;
- Conversas sociais, românticas, de grupo, Propósito, suporte e Cinema sobre um
  núcleo confiável;
- Perfil modular, expressivo e configurável;
- Modo Namoro, interesses, matches, descoberta, recados e Propósito Firmado;
- Loja, moedas, XP, transações, inventário, presentes e personalização;
- pets, Pet Arcade, caixas, missões, recompensas e jogos mantidos;
- conteúdo cristão e integração do Verbo — Bíblia & Estudo;
- Sala de Cinema com upload, processamento e reprodução sincronizada;
- confiança, verificação, moderação, bloqueios, denúncias e suporte;
- Administração por capacidades e métricas úteis;
- PWA, offline, cache privado, Realtime, desempenho e acessibilidade;
- aposentadoria segura de Pretendentes antigo, avatar-personagem, duplicações e
  código comprovadamente órfão;
- convergência final, observabilidade, reconciliação e preparação de release.

Não considere o programa concluído apenas porque a interface nova existe. A
meta é uma base realmente pronta: domínios separados, regras server-authoritative,
dados reconciliáveis, testes, feature flags, rollback, telemetria, experiência
responsiva e legado controlado.

## 2. Leia o contexto uma única vez

Antes de editar:

1. leia integralmente todos os `AGENTS.md` aplicáveis;
2. leia `00_LEIA_PRIMEIRO.md`;
3. leia `02_REGRAS_PERMANENTES_AGENTS.md`;
4. leia todos os documentos em `fontes-originais/`;
5. leia `03_MATRIZ_TOTAL_ESCOPO_DOMINIOS.md`;
6. leia `04_ROADMAP_LOTES_E_DEPENDENCIAS.md`;
7. leia `05_PROTOCOLOS_TRANSVERSAIS.md`;
8. leia `07_GATES_DECISOES_ANTONIO.md`;
9. leia `08_CHECKPOINT_CANONICO_V2_006.md`;
10. leia o estado persistente, se existir:
   `docs/reestruturacao-v2/20_EXECUTION_STATE.md`;
11. leia a especificação do primeiro lote ainda incompleto em `lotes/`.

Não volte a ler tudo a cada lote. Pesquise trechos relevantes quando necessário.
Não copie conteúdo desses documentos para a resposta. Use-os como fonte de
verdade.

## 3. Checkpoint conhecido e reconciliação automática

O último checkpoint conhecido antes deste pacote é:

- repositório: `tonyrodrigues98/vaidarnamorocristao`;
- `origin/main`: `0659a9616562a08182581362a3dd9b60923a66af`;
- Draft PR #7;
- branch: `rebuild/v2-006-legacy-audit`;
- head único: `79675aab2d97ef02ff40b320133b5be62225be3c`;
- V2-006: auditoria de legado corrigida e concluída;
- V2-007: Configurações/Conta, ainda não iniciada naquele checkpoint;
- 67 rotas;
- 445 referências tipadas;
- um link de rota não resolvido naquele momento: `/membros`;
- zero itens comprovadamente seguros para remoção;
- PR #7 aberto, Draft e não mesclado;
- nenhuma alteração operacional ou no Supabase.

Esse checkpoint pode ter evoluído legitimamente. Faça preflight silencioso:

- confirme repositório, remotes, branches, HEAD, worktree e PRs;
- leia commits e diffs posteriores;
- identifique o último lote realmente concluído;
- preserve todo trabalho válido;
- não exija que o usuário explique divergências causadas por progresso legítimo;
- não refaça V2-001 a V2-006 nem qualquer lote já aprovado pelos critérios;
- se houver mudanças não commitadas, entenda autoria e intenção antes de tocar;
- se houver conflito real ou mudança suspeita que possa destruir trabalho,
  interrompa somente a área afetada e continue o que for independente.

## 4. Autoridade concedida para esta execução

Você está autorizado a:

- analisar, implementar, refatorar, corrigir, testar e documentar;
- criar ou alterar arquivos necessários dentro do repositório;
- criar migrations aditivas e reversíveis sem aplicá-las em produção;
- usar projeto Supabase descartável quando já estiver configurado e for seguro;
- criar feature flags, adapters, contratos, telemetria e testes;
- criar branches, commits e Draft PRs;
- usar branches empilhadas quando a base anterior ainda estiver em Draft;
- fazer push somente das branches de trabalho;
- corrigir falhas encontradas dentro do lote atual;
- continuar automaticamente para o próximo lote seguro;
- usar decisões reversíveis de engenharia quando a documentação já define a
  intenção e o resultado;
- dividir um lote em mais de um Draft PR se isso reduzir risco.

Você não está autorizado a:

- fazer merge;
- marcar PR como Ready sem instrução explícita;
- fazer deploy;
- alterar `main` diretamente;
- aplicar migrations no Supabase publicado;
- executar `DROP`, `TRUNCATE`, exclusão de bucket/objeto ou limpeza de dados;
- expor, mover ou criar secrets;
- usar dados reais para testes destrutivos;
- apagar avatar-personagem, Pretendentes, jogos ou assets apenas por parecerem
  obsoletos;
- conceder moedas, XP, itens ou permissões em produção;
- tomar decisões jurídicas de exibição de vídeos;
- definir por Antonio quais jogos sairão;
- decidir compensação financeira por itens do avatar-personagem;
- realizar contração irreversível sem gate explícito.

## 5. Produto e decisões imutáveis

### Comunidade e Namoro

- Comunidade é a plataforma principal.
- Namoro é um modo opcional, desativado por padrão para novos usuários.
- Quem não ativou Namoro não vê Pretendentes, chamadas, filtros, badges,
  notificações, recados ou linguagem romântica.
- Estar fora do Namoro não retira ninguém da Comunidade.
- Conexão social, seguir, conversar e participar de grupos não significam
  interesse romântico.
- Bloqueio é global; silenciamento e denúncia são ações diferentes.

### Perfil

- O perfil será reconstruído como espaço expressivo e modular.
- A inspiração Steam significa liberdade de composição, vitrines e identidade,
  nunca clonagem visual.
- Configurações são simples, contextuais e laterais.
- Preservar foto principal, galeria, verificação, moderação, molduras, auras,
  fundos, capas, gradientes, presentes, stickers, badges, conquistas, pets e
  inventários legítimos.
- Avatar-personagem customizável será aposentado por protocolo separado.

### Início e Dashboard

- `/inicio` é hub social vivo: feed, novidades, conexões, Status e eventos.
- `/dashboard` permanece painel analítico separado.
- Não redirecionar uma rota para a outra.

### Conversas

- Reconstruir com envio otimista idempotente, ordenação estável, paginação,
  retry, estados de envio/entrega/leitura, Realtime, anexos, busca, bloqueio,
  denúncia, offline limitado e teclado mobile correto.
- Usar um núcleo compartilhado e políticas de participação por contexto.
- Não criar duas infraestruturas conflitantes para social e romance.

### Propósito Firmado e recados

- Preservar dados e função do Propósito Firmado.
- Um compromisso pausa somente o domínio romântico.
- Comunidade, amizades, conversas sociais, Verbo, pets, jogos e Cinema
  permanecem disponíveis.
- Recados anônimos existem somente no Namoro, com opt-in explícito do
  destinatário, limites e proteção contra abuso.

### Economia, inventário, pets e jogos

- Economia é server-authoritative e reconciliável.
- Toda alteração de saldo/XP tem causa, ledger e idempotência.
- Inventário é fonte de propriedade.
- Nenhum item comprado ou equipado pode sumir no redesign.
- Pets V1/V2 coexistem até reconciliação comprovada.
- Nenhum jogo será removido sem lista explícita de Antonio.
- Progresso, recompensas, missões, coleções e históricos são protegidos.

### Verbo e Cinema

- Verbo é uma experiência de Bíblia e estudo pessoal integrada à mesma conta,
  com privacidade e sem competição espiritual.
- Cinema usa vídeo previamente enviado e processado; não é compartilhamento de
  tela.
- Mídia de Cinema fica em Storage/CDN, nunca no Git.
- Cinema inclui sessões, host, catálogo, participantes, sincronização, chat,
  reações, moderação, recuperação de drift e experiência mobile.

### Administração

- Preservar capacidades legítimas e redesenhar por áreas/capabilities.
- Autorização real permanece no servidor/banco.
- Ações sensíveis exigem confirmação, motivo e auditoria.

## 6. Padrão técnico obrigatório

- monólito modular orientado por domínios; não criar microserviços agora;
- fatias verticais com `model`, `data`, `features` e `ui` quando fizer sentido;
- rotas finas;
- adapters entre domínio e Supabase;
- casos de uso públicos em vez de queries espalhadas;
- regras puras testáveis;
- operações privilegiadas apenas no servidor/banco;
- RLS e grants como autoridade;
- eventos internos explícitos para efeitos entre domínios;
- feature flags para mudança de comportamento;
- migração na ordem:
  `expandir → preencher → comparar → alternar → estabilizar → contrair`;
- PWA e Realtime preservados;
- mídia pesada fora do repositório;
- nenhuma dependência grande sem necessidade comprovada.

Não force uma árvore ideal sobre o código. Adapte a arquitetura ao stack e aos
padrões já estabelecidos pela V2, preservando import boundaries e evitando
abstrações cerimoniais.

## 7. Padrão visual obrigatório

- mobile-first real;
- excelente em desktop e tablet;
- Poppins;
- Lucide ou Heroicons;
- sem emojis de teclado como ícones de interface;
- identidade própria, premium, moderna, minimalista e expressiva;
- off-white/branco como base quando coerente com os tokens aprovados;
- motion intencional e compatível com `prefers-reduced-motion`;
- inputs com pelo menos 16 px no mobile para evitar zoom no iOS;
- safe areas, teclado, rotação e áreas de toque;
- WCAG 2.2 AA como referência;
- loading, vazio, erro, offline, permissão e conteúdo normal em toda superfície;
- não clonar Steam, Instagram, Discord, WhatsApp ou qualquer marca.

Referências:

- Steam: liberdade e vitrines do Perfil;
- Instagram: compreensão imediata e ritmo do Início;
- Discord: organização de espaços e presença da Comunidade;
- WhatsApp/Vitra: clareza de Conversas e Configurações;
- cinema online/watch party: sincronização e experiência social;
- protótipos do Sites: direção visual, nunca schema ou regra.

## 8. Motor de execução contínua

Repita este ciclo até concluir todos os lotes seguros:

1. Leia o lote atual em `lotes/`.
2. Inspecione somente o código e a documentação necessários.
3. Registre o contrato do lote em testes antes ou junto da implementação.
4. Implemente uma fatia vertical completa; não deixe apenas mock visual.
5. Preserve compatibilidade, flags e rollback.
6. Execute testes focados durante o trabalho.
7. Corrija regressões dentro do escopo.
8. Faça autorrevisão do diff, segurança, dados, acessibilidade e desempenho.
9. Execute os gates do lote.
10. Atualize `20_EXECUTION_STATE.md` de forma curta.
11. Crie commits intencionais.
12. Faça push da branch de trabalho e abra/atualize Draft PR.
13. Se o próximo lote puder ser iniciado com segurança, crie a branch empilhada
    e continue sem pedir confirmação.

Não mantenha um único PR gigante. Um lote pode conter mais de um Draft PR. Cada
PR deve ser revisável, ter objetivo coerente e manter o produto compilável.

## 9. Estado persistente e retomada

Mantenha `docs/reestruturacao-v2/20_EXECUTION_STATE.md` com no máximo o
necessário:

- data;
- branch, base e HEAD;
- PR atual e pilha;
- lote atual;
- critérios concluídos;
- próximo critério;
- decisões assumidas;
- blockers externos;
- migrations criadas e estado de aplicação;
- flags;
- testes relevantes;
- rollback;
- riscos restantes.

Não transforme o arquivo em diário de comandos. Atualize após um checkpoint
material, antes de trocar de lote e antes de terminar a sessão.

## 10. Git, branches e Draft PRs

### Se a base anterior foi mesclada

- atualize `origin/main`;
- crie o próximo branch a partir do novo `origin/main`.

### Se a base anterior continua em Draft

- confirme o head remoto;
- crie branch empilhada a partir desse head;
- use o PR anterior como base do novo PR quando suportado;
- registre claramente a dependência;
- nunca replique commits manualmente;
- após merges futuros, rebaseie com segurança e valide novamente.

### Regras

- nunca force push sem lease;
- nunca altere `main` diretamente;
- nunca apague trabalho alheio;
- preserve working tree do usuário;
- commits devem representar unidades revisáveis;
- PR permanece Draft;
- não faça merge nem deploy.

## 11. Validação eficiente

Durante edição, use testes focados. Em checkpoints materiais, execute:

- instalação congelada quando necessária;
- TypeScript;
- ESLint focado e depois global quando viável;
- Prettier/check de formato;
- testes novos;
- suítes de regressão afetadas;
- build cliente;
- build SSR;
- `git diff --check`;
- inspeção do bundle por secrets e imports server-only;
- checagem de dependências/ciclos/import boundaries;
- smoke test das rotas tocadas;
- acessibilidade e responsividade;
- teste de cache/sessão/PWA quando o lote tocar essas áreas.

Suítes que criam dados no Supabase só podem rodar em ambiente descartável
confirmado. Não transforme um bug atual em contrato permanente. Teste detectores
e invariantes de forma que uma correção futura continue passando.

## 12. Decisões e obstáculos

Não pare por:

- warning preexistente;
- lint localizado que pode ser corrigido;
- teste quebrado pelo próprio lote;
- refatoração adicional necessária para concluir a fatia;
- ausência de uma preferência estética pequena e reversível;
- falta de resposta para um módulo futuro que não bloqueia o atual;
- PR anterior ainda em Draft;
- indisponibilidade temporária de uma integração não necessária ao código local.

Pare a área afetada somente por:

- divergência de repositório/branch que possa destruir trabalho;
- segredo ou acesso que precise ser fornecido pelo usuário;
- migration/destruição no ambiente publicado;
- alteração operacional externa;
- decisão legal da Sala de Cinema;
- lista de jogos a remover;
- compensação do avatar-personagem;
- decisão de produto irreversível não coberta pelos documentos;
- conflito de dados sem estratégia segura de reconciliação;
- permissão negada que não possa ser contornada legitimamente.

Mesmo nesses casos, continue os lotes independentes que não dependem do gate.

## 13. Ordem dos lotes

Use `04_ROADMAP_LOTES_E_DEPENDENCIAS.md` e as especificações em `lotes/`.

Ordem-base:

1. V2-007 — Configurações/Conta.
2. V2-008 — verdade publicada, segurança e dados.
3. V2-009 — aquisição, identidade e onboarding.
4. V2-010 — Início, feed, vínculos sociais e Status.
5. V2-011 — Comunidade.
6. V2-012 — Conversas.
7. V2-013 — Perfil modular.
8. V2-014 — Modo Namoro.
9. V2-015 — Propósito Firmado, recados e presentes contextuais.
10. V2-016 — economia, Loja, inventário e personalização.
11. V2-017 — pets, Arcade, caixas e jogos.
12. V2-018 — conteúdo cristão e Verbo.
13. V2-019 — Sala de Cinema.
14. V2-020 — notificações, confiança, moderação e suporte.
15. V2-021 — Administração e métricas.
16. V2-022 — PWA, offline, desempenho e acessibilidade.
17. V2-023 — retirada lógica do legado.
18. V2-024 — reconciliação e contração autorizável.
19. V2-025 — convergência e preparação de release.

Dependências reais podem mudar a ordem, mas não podem eliminar escopo. Registre
qualquer reordenação no estado persistente.

## 14. Definição de conclusão do programa

O programa só pode ser chamado de tecnicamente concluído quando:

- os 17 domínios possuem fronteiras e contratos claros;
- rotas críticas deixaram de concentrar regras e queries extensas;
- Comunidade funciona sem Namoro;
- Namoro é opt-in e invisível quando desligado;
- Perfil, Início, Comunidade e Conversas atingiram a experiência-alvo;
- Propósito pausa somente romance;
- economia e inventário são reconciliáveis e server-authoritative;
- pets e jogos mantidos preservam progresso;
- Verbo e Cinema têm arquitetura integrada e rollout controlado;
- Administração opera por capacidades;
- PWA/cache não vazam dados entre contas;
- deep links são permitidos e same-origin;
- segurança P0/P1 foi confirmada ou tratada;
- dados têm snapshot, invariantes e plano de rollback;
- testes cobrem autorização, regressão, mobile, a11y, performance e offline;
- não há secrets privilegiados no cliente;
- legado não utilizado está caracterizado;
- nenhuma exclusão física ocorreu sem gate;
- Draft PRs estão revisáveis e o estado de cada flag/migration está documentado;
- todas as pendências que exigem Antonio estão isoladas e objetivas.

## 15. Resposta final — limite estrito

Ao terminar uma sessão longa, responda em no máximo 20 linhas:

- último lote e resultado;
- branches/PRs criados ou atualizados;
- testes/gates;
- próximo lote;
- bloqueadores externos reais;
- confirmação de que não houve merge, deploy ou mutation de produção.

Não recopie o objetivo, não liste cada arquivo e não produza relatório
explicativo, salvo se Antonio pedir.
